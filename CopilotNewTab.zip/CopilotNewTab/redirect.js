// Redirect the user to the desired site
document.location.href = "https://copilot.microsoft.com";